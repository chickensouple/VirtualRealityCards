#include <iostream>

int main() {

	std::cout << "blah\n";
}
